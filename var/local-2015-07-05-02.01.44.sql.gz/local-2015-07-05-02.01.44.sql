-- MySQL dump 10.13  Distrib 5.5.43, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: stafeta
-- ------------------------------------------------------
-- Server version	5.5.43-0+deb7u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `category_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Family'),(2,'Juniori'),(3,'Elite'),(4,'Open'),(5,'Veterani'),(6,'Feminin');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category_challenges`
--

DROP TABLE IF EXISTS `category_challenges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category_challenges` (
  `category_challenge_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` mediumint(8) unsigned NOT NULL,
  `challenge_id` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`category_challenge_id`),
  KEY `fk_category_challenges_categories_1` (`category_id`),
  KEY `fk_category_challenges_challenges_1` (`challenge_id`),
  CONSTRAINT `fk_category_challenges_categories_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`),
  CONSTRAINT `fk_category_challenges_challenges_1` FOREIGN KEY (`challenge_id`) REFERENCES `challenges` (`challenge_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category_challenges`
--

LOCK TABLES `category_challenges` WRITE;
/*!40000 ALTER TABLE `category_challenges` DISABLE KEYS */;
INSERT INTO `category_challenges` VALUES (1,1,1),(2,5,1),(3,4,1);
/*!40000 ALTER TABLE `category_challenges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `challenge_stations`
--

DROP TABLE IF EXISTS `challenge_stations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `challenge_stations` (
  `station_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `category_challenge_id` mediumint(8) unsigned DEFAULT NULL,
  `station_type` tinyint(2) unsigned DEFAULT NULL COMMENT '0 = START, 1 = PA, 2 = PFA, 3 = FINISH',
  `maximum_time` mediumint(8) DEFAULT NULL,
  `score` mediumint(8) DEFAULT NULL,
  PRIMARY KEY (`station_id`),
  KEY `fk_challenge_raid_stations_category_challenges_1` (`category_challenge_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `challenge_stations`
--

LOCK TABLES `challenge_stations` WRITE;
/*!40000 ALTER TABLE `challenge_stations` DISABLE KEYS */;
INSERT INTO `challenge_stations` VALUES (1,1,0,NULL,NULL),(2,1,1,70,NULL),(3,1,2,NULL,200),(4,1,3,NULL,NULL),(5,1,1,50,NULL),(6,1,2,NULL,200),(7,2,0,NULL,NULL),(8,2,1,50,NULL),(9,2,3,NULL,NULL),(10,2,2,NULL,200),(11,2,1,70,NULL),(12,2,1,70,NULL),(13,3,0,NULL,NULL),(14,3,1,60,NULL),(15,3,1,120,NULL),(16,3,1,80,NULL),(17,3,2,NULL,200),(18,3,2,NULL,200),(19,3,2,NULL,200),(20,3,3,NULL,NULL);
/*!40000 ALTER TABLE `challenge_stations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `challenges`
--

DROP TABLE IF EXISTS `challenges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `challenges` (
  `challenge_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `challenge_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`challenge_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `challenges`
--

LOCK TABLES `challenges` WRITE;
/*!40000 ALTER TABLE `challenges` DISABLE KEYS */;
INSERT INTO `challenges` VALUES (1,'Raid montan'),(2,'Orientare'),(3,'Cunostinte turistice'),(4,'Cultural');
/*!40000 ALTER TABLE `challenges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `climbing`
--

DROP TABLE IF EXISTS `climbing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `climbing` (
  `climbing_id` int(8) NOT NULL AUTO_INCREMENT,
  `team_id` mediumint(8) NOT NULL,
  `name_participant` varchar(255) NOT NULL,
  `missed_nods` mediumint(8) DEFAULT NULL,
  `top` mediumint(8) DEFAULT NULL,
  `timp` varchar(255) NOT NULL,
  `abandon` mediumint(8) DEFAULT NULL,
  PRIMARY KEY (`climbing_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `climbing`
--

LOCK TABLES `climbing` WRITE;
/*!40000 ALTER TABLE `climbing` DISABLE KEYS */;
INSERT INTO `climbing` VALUES (1,72,'Popescu Ion',0,0,'11:22:33',0),(2,74,'Marian Busoi',0,26,'00:01:02',0),(3,75,'ffdf gfgfgfgfgf',0,99,'00:02:00',1),(4,76,'krlkrtiortiotro sdhsdjsdsj',2,20,'00:04:02',0),(5,77,'pipoioioi urururururu',1,18,'00:03:00',0),(6,78,'oroiriorirto yerueryureyre',2,99,'00:04:00',0),(7,79,'lslslslsk hjdhdhdhdh',0,0,'00:00:00',0),(8,80,'-',0,0,'00:00:00',1);
/*!40000 ALTER TABLE `climbing` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clubs`
--

DROP TABLE IF EXISTS `clubs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clubs` (
  `club_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `club_name` varchar(255) NOT NULL,
  `scor_cultural` mediumint(8) NOT NULL,
  PRIMARY KEY (`club_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clubs`
--

LOCK TABLES `clubs` WRITE;
/*!40000 ALTER TABLE `clubs` DISABLE KEYS */;
INSERT INTO `clubs` VALUES (12,'Asociatia Drumetii Montane',30),(13,'Arcul Carpatin',0),(14,'Zimbrul Carpatin',35),(15,'Gaska Bucuresti',36);
/*!40000 ALTER TABLE `clubs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `knowledge`
--

DROP TABLE IF EXISTS `knowledge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `knowledge` (
  `knowledge_id` int(8) NOT NULL AUTO_INCREMENT,
  `team_id` mediumint(8) NOT NULL,
  `answers` mediumint(8) NOT NULL,
  `time` varchar(255) NOT NULL,
  `scor` mediumint(8) NOT NULL,
  `abandon` mediumint(8) NOT NULL,
  PRIMARY KEY (`knowledge_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `knowledge`
--

LOCK TABLES `knowledge` WRITE;
/*!40000 ALTER TABLE `knowledge` DISABLE KEYS */;
INSERT INTO `knowledge` VALUES (1,72,2,'00:01:23',260,0),(2,73,0,'00:05:23',0,1),(3,74,0,'00:06:23',300,0),(4,75,0,'00:03:22',300,0),(5,76,0,'00:02:02',0,1),(6,77,0,'00:01:55',300,0),(7,78,0,'00:04:24',300,0),(8,79,0,'00:04:44',300,0),(9,80,0,'00:00:00',0,1);
/*!40000 ALTER TABLE `knowledge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organizer`
--

DROP TABLE IF EXISTS `organizer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `organizer` (
  `id_organizer` int(1) NOT NULL AUTO_INCREMENT,
  `name_trophy` varchar(255) NOT NULL,
  `name_organizer` varchar(255) NOT NULL,
  `phase_trophy` varchar(255) NOT NULL,
  PRIMARY KEY (`id_organizer`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organizer`
--

LOCK TABLES `organizer` WRITE;
/*!40000 ALTER TABLE `organizer` DISABLE KEYS */;
INSERT INTO `organizer` VALUES (1,'Festivalul Drumetii Montane, Etapa III','Asociatia Drumetii Montane','Challange');
/*!40000 ALTER TABLE `organizer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orienteering`
--

DROP TABLE IF EXISTS `orienteering`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orienteering` (
  `orienteering_id` int(8) NOT NULL AUTO_INCREMENT,
  `team_id` mediumint(8) NOT NULL,
  `name_participant` varchar(255) NOT NULL,
  `start` varchar(255) NOT NULL,
  `finish` varchar(255) NOT NULL,
  `total` varchar(8) NOT NULL,
  `abandon` mediumint(8) NOT NULL,
  `missed_posts` mediumint(8) NOT NULL,
  PRIMARY KEY (`orienteering_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orienteering`
--

LOCK TABLES `orienteering` WRITE;
/*!40000 ALTER TABLE `orienteering` DISABLE KEYS */;
INSERT INTO `orienteering` VALUES (9,72,'Participant 1','00:12:00','00:16:00','00:04:00',0,0),(10,73,'kdjdjdj djdjdjdj','00:11:00','00:17:00','00:06:00',0,0),(11,74,'hjjhjjhj rrttrtrrtrt','00:19:12','00:26:00','00:06:48',0,0),(12,75,'lslsllss hahha','00:17:56','00:22:45','00:04:49',0,0),(13,76,'uieieruier sdhjdhdsjsd','00:00:00','00:00:00','00:00:00',0,1),(14,77,'kldkldkldkldf hjshsjhjsd','00:25:00','00:44:45','00:19:45',0,0),(15,78,'potypytopytpo irot','00:00:00','00:00:00','00:00:00',1,0),(16,79,'Pooddin hdhdh','00:34:00','00:43:00','00:09:00',0,0);
/*!40000 ALTER TABLE `orienteering` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `participation_entries`
--

DROP TABLE IF EXISTS `participation_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `participation_entries` (
  `entry_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `participation_id` mediumint(8) unsigned NOT NULL,
  `station_id` mediumint(8) unsigned DEFAULT NULL,
  `participant_name` varchar(255) DEFAULT NULL,
  `time` varchar(32) DEFAULT NULL,
  `time_start` varchar(32) DEFAULT NULL,
  `time_finish` varchar(32) DEFAULT NULL,
  `hits` tinyint(3) DEFAULT NULL,
  PRIMARY KEY (`entry_id`),
  KEY `fk_participation_entries_participations_1` (`participation_id`),
  KEY `fk_participation_entries_challenge_stations_1` (`station_id`),
  CONSTRAINT `fk_participation_entries_challenge_stations_1` FOREIGN KEY (`station_id`) REFERENCES `challenge_stations` (`station_id`),
  CONSTRAINT `fk_participation_entries_participations_1` FOREIGN KEY (`participation_id`) REFERENCES `participations` (`participation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `participation_entries`
--

LOCK TABLES `participation_entries` WRITE;
/*!40000 ALTER TABLE `participation_entries` DISABLE KEYS */;
INSERT INTO `participation_entries` VALUES (1,1,1,NULL,NULL,'10:12:51','0h:mm:ss',NULL),(2,1,2,NULL,NULL,'11:55:54','11:22:56',NULL),(3,1,5,NULL,NULL,'14:25:21','13:12:54',NULL),(4,1,3,NULL,NULL,NULL,NULL,0),(5,1,6,NULL,NULL,NULL,NULL,1),(6,1,4,NULL,NULL,'0h:mm:ss','18:25:52',NULL),(7,2,13,NULL,NULL,'08:12:00','',NULL),(8,2,14,NULL,NULL,'08:55:00','08:50:00',NULL),(9,2,15,NULL,NULL,'10:05:00','10:00:00',NULL),(10,2,16,NULL,NULL,'10:50:00','10:45:00',NULL),(11,2,17,NULL,NULL,NULL,NULL,1),(12,2,18,NULL,NULL,NULL,NULL,1),(13,2,19,NULL,NULL,NULL,NULL,1),(14,2,20,NULL,NULL,'','11:45:00',NULL);
/*!40000 ALTER TABLE `participation_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `participations`
--

DROP TABLE IF EXISTS `participations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `participations` (
  `participation_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `team_id` mediumint(8) unsigned NOT NULL,
  `category_challenge_id` mediumint(8) unsigned NOT NULL,
  `score` int(12) DEFAULT NULL,
  `notes` text,
  `missing_equipment_items` tinyint(2) DEFAULT '0',
  `missing_footwear` char(1) DEFAULT 'N',
  PRIMARY KEY (`participation_id`),
  KEY `fk_challenge_participation_teams_1` (`team_id`),
  KEY `fk_challenge_participation_category_challenges_1` (`category_challenge_id`),
  CONSTRAINT `fk_challenge_participation_category_challenges_1` FOREIGN KEY (`category_challenge_id`) REFERENCES `category_challenges` (`category_challenge_id`),
  CONSTRAINT `fk_challenge_participation_teams_1` FOREIGN KEY (`team_id`) REFERENCES `teams` (`team_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `participations`
--

LOCK TABLES `participations` WRITE;
/*!40000 ALTER TABLE `participations` DISABLE KEYS */;
INSERT INTO `participations` VALUES (1,73,1,NULL,NULL,0,'N'),(2,72,3,NULL,NULL,0,'N');
/*!40000 ALTER TABLE `participations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `setting_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `value` text,
  PRIMARY KEY (`setting_id`,`code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teams`
--

DROP TABLE IF EXISTS `teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teams` (
  `team_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `team_name` varchar(255) DEFAULT NULL,
  `club_id` mediumint(8) unsigned DEFAULT NULL,
  `category_id` mediumint(8) unsigned DEFAULT NULL,
  PRIMARY KEY (`team_id`),
  KEY `fk_teams_clubs_1` (`club_id`),
  KEY `fk_teams_categories_1` (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teams`
--

LOCK TABLES `teams` WRITE;
/*!40000 ALTER TABLE `teams` DISABLE KEYS */;
INSERT INTO `teams` VALUES (72,'Echipa 1 Drumetie',12,4),(73,'Echipa 2 Drumetie',12,1),(74,'Arcul 1',13,4),(75,'Arcul 2',13,4),(76,'Zimbrul 1',14,4),(77,'Zimbrul 2',14,4),(78,'Gask 1',15,4),(79,'Gaska 2',15,4),(80,'Zimbruletu',14,4);
/*!40000 ALTER TABLE `teams` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-07-05  2:01:44
